<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 ">
                <div class="card">
                    <div class="card-header h2" align="center">Event Details:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($event->eventName); ?>

                    </div>
                    <div class="card-body">

                            <label class="col-form-label"> Event Manager</label>
                            <input type="text" class="form-control" name="eventOwner" value="<?php echo e($event->eventOwner); ?>" readonly>

                            <label class="col-form-label"> Location & Room </label>
                            <input type="text" class="form-control" name="eventLocation" value="<?php echo e($event->eventLocation); ?>" readonly>
                            <label class="col-form-label"> Dates Available </label>
                            <input type="date"  class="form-control" name="eventDate1" value="<?php echo e($event->eventDate1); ?>" readonly>
                            <br>
                            <input type="date"  class="form-control" name="eventDate2" value="<?php echo e($event->eventDate2); ?>" readonly>
                            <label class="col-form-label"> Event Description</label>
                            <textarea type="text" class="form-control" name="eventDescription" readonly><?php echo e($event->eventDescription); ?>

                        </textarea>

                            <label class="col-form-label"> # Of Participants</label>
                            <!-- Taking count of users, registered for an event here: -->
                            <input type="text" class="form-control" name="eventDescription" value="<?php echo e($event->users()->count()); ?>" readonly><hr>
                            <?php echo e(csrf_field()); ?>


                            <div class="offset-5">
                                <a href="https://w9team1.gblearn.com/GBCEvent/public/home" class="btn btn-success">Home</a>
                            </div>


                    </div>
                </div>
            </div>
            <div class="col-md-6" >
                <p id="stamp">
                    Today is:&nbsp;&nbsp;&nbsp;&nbsp;
                    
                    <span id="ct"></span>

                </p>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2885.655434645947!2d-79.41267698477124!3d43.67613545896579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b349c7e14727f%3A0x8bd06e05bd9af30d!2sGeorge+Brown+College+Casa+Loma+Campus!5e0!3m2!1sen!2sca!4v1549924732006" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>