<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading"><h2>Edit Record:</h2></div>

                    <form action="/update/<?php echo e($message->id); ?>" method="post">
                        <input type="text" name="title" value="<?php echo e($message->title); ?>">
                        <input type="text" name="msg" value="<?php echo e($message->content); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" name="Submit" value="Save">
                        <a href="/home"><button>Cancel</button></a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>