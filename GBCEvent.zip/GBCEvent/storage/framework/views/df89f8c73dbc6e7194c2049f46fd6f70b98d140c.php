<?php $__env->startSection('content'); ?>

<!--@svg('brands/github')
@svg('regular/bars', 'text-white') // I thought this directive would work for fontawesome, nope. -->

  <script src="https://kit.fontawesome.com/bb250377d6.js" crossorigin="anonymous"></script>

    <div class="container">
        <div class="row">
            <div class="col-md-9 offset-1">

                <div class="card-header h2" align="center">
                    Main Dashboard 
                    <div class="row" style="height: 20px">
                    </div>
                     <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                                <i class="fas fa-sitemap"></i>&nbsp;<h5> 4 Events created</h5>
                            </div>
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                               <i class="fa fa-users"></i>&nbsp; <h5 class="text-success"> 10 new Participants </h5>
                            </div>
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                               <i class="fas fa-key"></i>&nbsp;<h5 class="text-success"> 5 new Owners's requests </h5>
                            </div>
                        </div>
                       <div class="row" style="height: 15px">
                       </div>
                        <div class="row">
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                                <i class="far fa-bell"></i>&nbsp;<h5 class="text-success"> 2 Users Registered </h5>
                            </div>
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                                <i class="far fa-comments"></i>&nbsp;<h5 class="text-success"> 5 Comments Added </h5>
                            </div>
                            <div class="col-md-3 offset-1 border border-success text-success bg-light" style="height: 80px; width: 100px" >
                               <i class="fas fa-paperclip"></i>&nbsp;<h5 class="text-success"> 6 Files Attached </h5>
                            </div>
                        </div>
                     </div>
                    <div class="row" style="height: 20px">
                    </div>
                    

                            <!--div class="navbar navbar-default "-->
                              <div class="container-fluid">
                           
                               <ul class="nav navbar-nav"> 
                              <table class = "table table-hover card-header h4">
                                  <thead>
                                  
                              
                                 <th><li class="active"><a href="/home"><i class="fa fa-home-lg-alt"></i>Home </a></li></th>
                                 
                                  <th><li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="far fa-calendar-alt"></i>&nbsp; Events <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="/callcreate">Create Event</a></li>
                                      <li><a href="/profile">My Events</a></li>
                                      <li><a href="#">All New Events</a></li>
                                      <li><a href="#">Current Changes</a></li>
                                      <li><a href="#">Delete Events</a></li>
                                     </ul>
                                   </li>
                                </th>
                                <th>
                                  
                                   <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-users"></i>&nbsp; Users <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="#">Create New Owner</a></li>
                                      <li><a href="#">Change User Status</a></li>
                                      <li><a href="#">Delete User</a></li>
                                    </ul>
                                  </li>
                                </th>
                                <th>
                                   <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="far fa-comments"></i>&nbsp;Comments <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="#">New Comments</a></li>
                                      <li><a href="#">Delete Comment</a></li>
                                    </ul>
                                  </li>
                            
                                </th>
                                
                                 </thead>
                                </table>
                                </ul>
                              </div>
                            <!--/div-->

</div>



                    
                    <!--<div class="card-header h4" align="center">
                        Events 
                    </div> -->
                    
                    
                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class = "table table-hover">
                            <thead>
                                <th>Title</th>
                                <th>Owner</th>
                                <th>Date1</th>
                                <th>Date2</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                        <td><?php echo e(Auth::user()->name); ?>&nbsp;<?php echo e(Auth::user()->lname); ?></td>
                                        <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime1); ?></td>
                                        <td><?php echo e($event->eventDate2); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime2); ?></td>
                                        <td><?php echo e($event->eventLocation); ?>, <?php echo e($event->eventRoom); ?></td>
                                        <td><?php echo e($event->eventDescription); ?></td>
                                        
                                        <td>
                                            <?php if($event->status_enabled > 2): ?> 
                                                <span class="text-danger">Blocked / 
                                                <?php if($event->status_enabled == 3): ?>
                                                    Descrimination issue
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 4): ?>
                                                    Scope issue
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 5): ?>
                                                    Not Legal 
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 6): ?>
                                                    Contact college administration for details
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 7): ?>
                                                    Date, Time  or Location adjustment required 
                                                <?php endif; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-success">Enabled</span>
                                            <?php endif; ?>
                                        </td>



                                        <td>
                                            <!--<a href="/editrec/">Post It</a> -->
                                            <a onclick="return myFunctionEvent();"href="/allowEvent/<?php echo e($event->id); ?>">Make&nbspVisible</a>
                                            <br>
                                            <a onclick="return myFunction();"href="/delete/<?php echo e($event->id); ?>">Delete</a>
                                            <br>
                                            <a onclick="return FunctionBlock();"href="/refuse/<?php echo e($event->id); ?>">Block Event</a>

                                            <script>
                                                function myFunction() {
                                                    if(!confirm("Are you sure to delete this event?"))
                                                         {event.preventDefault()} else
                                                    alert("This event has been deleted from the system!");
                                                }
                                                function myFunctionEvent() {
                                                    if(!confirm("Ok to make this visible to users?"))
                                                         {event.preventDefault()} else
                                                    alert("This event is successfully published!");
                                                }
                                                function FunctionBlock() { 
                                                    if(!confirm("You are about to block an event.."))
                                                         {event.preventDefault()} else
                                                    alert("Redirecting..");
                                                }
                                            </script>
                                            <!--<br>
                                            <a href="">View&nbsp;Report</a>-->
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                    <hr>
                        <div class="card-header h4" align="center">
                            Users
                        </div>
                        <table class = "table table-hover">
                            <thead>
                            <th>Full name</th>
                            <th>Email</th>
                            <th>Email verified</th>
                            <th>Actions</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td><?php echo e($user->lname); ?>,&nbsp <?php echo e($user->name); ?>&nbsp;</td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->email_verified_at); ?></td>
                                    <td>
                                        <a onclick="return myFunctionOwner();"href="/makeOwner/<?php echo e($user->id); ?>">Make an Owner</a>
                                        <br>
                                        <a onclick="return myFunctionBlock();"href="/blockUser/<?php echo e($user->id); ?>">Block account</a>
                                        <br>
                                        <a onclick="return myFunctionUser();"href="/deleteUser/<?php echo e($user->id); ?>">Delete user</a>

                                        <script>
                                            function myFunctionUser() {
                                                if(!confirm("Do you want to completely delete this account?"))
                                                     {event.preventDefault()} else
                                                    alert("This account has been terminated!");
                                            }
                                            function myFunctionBlock() {
                                                if(!confirm("Do you want to block this account?"))
                                                    {event.preventDefault()} else
                                                    alert("This account has been blocked!");
                                            }
                                           function myFunctionOwner() {
                                                if(!confirm("Do you want allow this user to create new events?"))
                                                {event.preventDefault()} else
                                                    alert("Owner successfully created!");
                                            }
                                        </script>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <br>
                        <hr>
                        <div class="card-header h4" align="center">
                            Comments
                        </div>
                        <table class = "table table-hover">
                            <thead>
                            <th>Event id</th>
                            <th>User id</th>
                            <th>Message</th>
                            <th>Created</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><a href="/viewrec/<?php echo e($comment->event_id); ?>"><?php echo e($comment->event_id); ?></a></td>
                                    <td><a href="/viewrec/<?php echo e($comment->user_id); ?>"><?php echo e($comment->user_id); ?></a></td>
                                    <td><?php echo e($comment->message); ?></td>
                                    <td><?php echo e($comment->created_at); ?></td>
                                    <td>
                                        <a onclick="return myFunctionEvent();"href="/Post/<?php echo e($user->id); ?>">Post it</a>
                                        <br>
                                        <a onclick="return myFunctionStop();"href="/blockComment/<?php echo e($user->id); ?>">Block comment</a>
                                        <br>
                                        <a onclick="return myFunctionDiscard();"href="/discardComment/<?php echo e($user->id); ?>">Discard</a>

                                        <script>
                                            function myFunctionStop() {
                                                if(!confirm("Are you sure you want to block the comment?"))
                                                    event.preventDefault();
                                            }
                                            function myFunctionDiscard() {
                                                if(!confirm("Discard this comment?"))
                                                    event.preventDefault();
                                            }
                                        </script>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                          <br>
                    
                        <div class="col-6 offset-4">
                         <!-- Declaration for $events was here-->

                        </div>
                </div>
               </div>

                <a href="/callcreate"><button class="btn btn-success new"><i class="fas fa-plus"></i></button></a>
                <a href="/profile"><button class="btn btn-success"> <i class="far fa-calendar-alt"></i>&nbsp;My Events </button></a>
                <a href="/home"><button class="btn btn-success"> Upcoming events </button></a>
            <br>
            <p>New events and comments will be displayed to users after the approval</p>

        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>