<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>GBCEvents</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


    </head>

    <body>

        <div id="app">
            <nav class="navbar navbar-expand-md navbar-light navbar-laravel">

                <?php if(Route::has('login')): ?>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <div class="navbar_brand">
                                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('images/logo.jpg')); ?>"/></a>
                                </div>
                            </li>
                        </ul>
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">

                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/home')); ?>">Home</a>
                            </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                                    </li>
                                <?php endif; ?>
                        <?php endif; ?>
                        </ul>

                    </div>
                <?php endif; ?>
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-2">
                        <div class="card">
                            <div class="card-header h2" align="center">Upcoming Events</div>
                                <div class="card-body">
                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <table class = "table table-hover">
                                            <thead>
                                            <th>Title</th>
                                            <th>Owner</th>
                                            <th>Dates</th>
                                            <th>Location</th>
                                            <th>Description</th>

                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                                <tr>
                                                    <td><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                                    <td><?php echo e($event->eventOwner); ?></td>
                                                    <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventDate2); ?></td>
                                                    <td><?php echo e($event->eventLocation); ?></td>
                                                    <td><?php echo e($event->eventDescription); ?></td>
                                                </tr>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <div class="col-6 offset-4">
                                            <?php echo e($events->links()); ?>

                                        </div>
                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
    </body>
</html>
