<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <form action="/create" method="post">
                        <input type="text" name="title" placeholder="Title">
                        <input type="text" name="msg" placeholder="Content">
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" name="Submit" value="Add record">
                    </form>

                </div>
                <div class="panel-heading"><h2>List of messages:</h2></div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class = "table table-hover table-bordered">
                        <thead>
                          <tr>
                              <th>Title</th>
                              <th>Content</th>
                              <th>Created</th>
                              <th>Actions</th>
                          </tr>
                        </thead>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($message->title); ?></td>
                                <td><a href="/viewrec/<?php echo e($message->id); ?>"><?php echo e($message->content); ?></a></td>
                                <td><?php echo e($message->created_at); ?></td>
                                <td>
                                    <a href="/editrec/<?php echo e($message->id); ?>">Edit</a>
                                    |
                                    <a href="/delete/<?php echo e($message->id); ?>">Delete</a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </table>
                    <?php echo e($messages->links()); ?>

                  </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>