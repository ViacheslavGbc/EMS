<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2">
                <div class="card">
                    <div class="card-header h2" align="center">
                        Create An Event
                    </div>
                    <div class="card-body">
                        <form action="https://w9team1.gblearn.com/GBCEvent/public/create" method="post">

                            <label class="col-form-label">Event Manager</label>
                            <input type="text" name="eventOwner" class="form-control" placeholder="Owner Name" required>
                            <label class="col-form-label"> Full Event Title </label>
                            <input type="text" name="eventName" class="form-control" placeholder="Master-Class" required>
                            <label class="col-form-label">Dates & Times</label>
                            <input type="date" name="eventDate1" class="form-control" required>
                            <br>
                            <input type="date" name="eventDate2" class="form-control" >
                            <label class="col-form-label">Location & Room </label>
                            <input type="text" name="eventLocation" class="form-control" placeholder="GBC Casa-Loma campus, C418" required >
                            <label class="col-form-label">Max. Participants</label>
                            <input type="text" name="maxNumParticipants" class="form-control" placeholder="100" required>
                            <label class="col-form-label">Detailed Description</label>
                            <textarea type="text" name="eventDescription" class="form-control"
                                      rows=4 placeholder="Unexpectedly sharp and bright seminar" required>
                            </textarea>
                            <br>

                            <?php echo e(csrf_field()); ?>

                            <div class="col-sm-6 offset-4">
                                <input type="submit" name="Submit" class="btn btn-success" value="Add Record">&nbsp&nbsp&nbsp&nbsp
                                <a href="https://w9team1.gblearn.com/GBCEvent/public/home" class="btn-success btn">Cancel</a>


                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>