<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9 offset-1">

                <div class="card-header h2" align="center">
                    Main Dashboard
                    <div class="card-header h4" align="center">
                        Events <!--Upcoming Events-->
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class = "table table-hover">
                            <thead>
                                <th>Title</th>
                                <th>Owner</th>
                                <th>Date1</th>
                                <th>Date2</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                        <td><?php echo e(Auth::user()->name); ?>&nbsp;<?php echo e(Auth::user()->lname); ?></td>
                                        <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime1); ?></td>
                                        <td><?php echo e($event->eventDate2); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime2); ?></td>
                                        <td><?php echo e($event->eventLocation); ?>, <?php echo e($event->eventRoom); ?></td>
                                        <td><?php echo e($event->eventDescription); ?></td>

                                        <td>
                                            <!--<a href="/editrec/">Post It</a> -->
                                            <a onclick="return myFunctionEvent();"href="/allowEvent/<?php echo e($event->id); ?>">Make&nbspVisible</a>
                                            <br>
                                            <a onclick="return myFunction();"href="/delete/<?php echo e($event->id); ?>">Delete</a>

                                            <script>
                                                function myFunction() {
                                                    if(!confirm("Are you sure to delete this event?"))
                                                        event.preventDefault();
                                                }
                                                function myFunctionEvent() {
                                                    if(!confirm("Make this event visible to users?"))
                                                        event.preventDefault();
                                                }
                                            </script>
                                            <br>
                                            <a href="">View&nbspReport</a>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                    <hr>
                        <div class="card-header h4" align="center">
                            Users
                        </div>
                        <table class = "table table-hover">
                            <thead>
                            <th>Full name</th>
                            <th>Email</th>
                            <th>Email verified</th>
                            <th>Actions</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td><?php echo e($user->lname); ?>,&nbsp <?php echo e($user->name); ?>&nbsp;</td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->email_verified_at); ?></td>
                                    <td>
                                        <a href="/makeOwner/<?php echo e($user->id); ?>">Make an Owner</a>
                                        <br>
                                        <a onclick="return myFunction();"href="/blockUser/<?php echo e($user->id); ?>">Block account</a>
                                        <br>
                                        <a onclick="return myFunction();"href="/deleteUser/<?php echo e($user->id); ?>">Delete user</a>

                                        <script>
                                            function myFunction() {
                                                if(!confirm("Are you sure to delete this event?"))
                                                    event.preventDefault();
                                            }
                                        </script>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <br>
                        <hr>
                        <div class="card-header h4" align="center">
                            Comments
                        </div>
                        <table class = "table table-hover">
                            <thead>
                            <th>Event id</th>
                            <th>User id</th>
                            <th>Message</th>
                            <th>Created</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><a href="/viewrec/<?php echo e($comment->event_id); ?>"><?php echo e($comment->event_id); ?></a></td>
                                    <td><a href="/viewrec/<?php echo e($comment->user_id); ?>"><?php echo e($comment->user_id); ?></a></td>
                                    <td><?php echo e($comment->message); ?></td>
                                    <td><?php echo e($comment->created_at); ?></td>
                                    <td>
                                        <a href="/Post/<?php echo e($user->id); ?>">Post it</a>
                                        <br>
                                        <a onclick="return myFunction();"href="/blockComment/<?php echo e($user->id); ?>">Block comment</a>
                                        <br>
                                        <a onclick="return myFunction();"href="/discardComment/<?php echo e($user->id); ?>">Discard</a>

                                        <script>
                                            function myFunction() {
                                                if(!confirm("Are you sure to delete this event?"))
                                                    event.preventDefault();
                                            }
                                        </script>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                          <br>
                    
                        <div class="col-6 offset-4">
                         <!-- Declaration for $events was here-->

                        </div>
                </div>
               </div>

                <a href="/callcreate"><button class="btn btn-success new">+</button></a>
                <a href="/profile"><button class="btn btn-success"> My Events </button></a>
                <a href="/home"><button class="btn btn-success"> Upcoming events </button></a>
            <br>
            <p>New events and comments will be displayed to users after approval</p>

        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>