<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>GBCEvents</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link rel="shortcut icon" type="image/ico" href="favicon.ico"/>

        <style>
            body{
                background-color: #d4d8f9;
            }
            .navbar{
                background-color: #e0e3f9;
            }
        </style>

    </head>

    <body>

        <div id="app">
            <nav class="navbar navbar-expand-md navbar-light navbar-laravel">

                <?php if(Route::has('login')): ?>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <div class="navbar_brand">
                                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('images/logo.jpg')); ?>"/></a>
                                </div>
                            </li>
                        </ul>
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">

                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/home')); ?>">Home</a>
                            </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                                    </li>
                                <?php endif; ?>
                        <?php endif; ?>
                        </ul>

                    </div>
                <?php endif; ?>
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-2">
                        <div class="card">
                            <div class="card-header h2" align="center">Upcoming Events

                            </div>
                            <form method="get" action="/" >
                                <input type="text" name="Search" class="form-control col-3" placeholder="Type here to search">
                                <input type="submit" name="Search" value="Search">
                                <!-- if (txtValue.toUpperCase().indexOf(filter) > -1) {  <-something like this  -->
                            </form>

                            </div>
                                <div class="card-body">
                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <table class = "table table-hover">
                                            <thead>
                                            <th>Title</th>
                                            <th>Owner</th>
                                            <th>Date 1</th>
                                            <th>Date 2</th>
                                            <th>Location</th>
                                            <th>Description</th>

                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php if($event->status_enabled > 0): ?>  <!-- if event is approved by admin - display it ! -->
                                                <tr>
                                                    <td><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                                    <td><?php echo e($event->eventOwner); ?></td>
                                                    <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime1); ?></td>
                                                    <td><?php echo e($event->eventDate2); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime2); ?></td>
                                                    <td><?php echo e($event->eventLocation); ?>, <?php echo e($event->eventRoom); ?></td>
                                                    <td><?php echo e($event->eventDescription); ?></td>
                                                </tr>
                                              <?php endif; ?>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <div class="col-6 offset-4">
                                            <?php echo e($events->links()); ?>

                                        </div>
                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
    </body>
</html>
