<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-6 ">
                <div class="card">
                    <div class="card-header h2" align="center">Event Details:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($event->eventName); ?></div>
                    <div class="card-body">

                            <div class="row">
                                <label class="col-form-label col-6"> Event Manager: </label>
                                <input type="text" class="form-control col-6" name="eventOwner" value="<?php echo e($event->eventOwner); ?>" readonly>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-form-label col-6"> Location </label>
                                <input type="text" class="form-control col-6" name="eventLocation" value="<?php echo e($event->eventLocation); ?>" readonly>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-form-label col-6"> Room </label>
                                <input type="text" class="form-control col-6" name="eventRoom" value="<?php echo e($event->eventRoom); ?>" readonly>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-form-label col-6"> Dates </label>
                                <p class="col-6">
                                    <input type="date"  class="form-control" name="eventDate1" value="<?php echo e($event->eventDate1); ?>" readonly>
                                    <input type="time"  class="form-control" name="eventTime1" value="<?php echo e($event->eventTime1); ?>" readonly>
                                    <br>
                                    <input type="date"  class="form-control" name="eventDate2" value="<?php echo e($event->eventDate2); ?>" readonly>
                                    <input type="time"  class="form-control" name="eventTime2" value="<?php echo e($event->eventTime2); ?>" readonly>
                                </p>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-form-label col-6"> Event Description</label>
                                <textarea type="text" class="form-control col-6" name="eventDescription" readonly><?php echo e($event->eventDescription); ?></textarea>
                            </div>
                            <br>

                            <div class="row">
                                <label class="col-form-label col-6"> # Of Participants</label>
                                <!-- Taking count of users, registered for an event here: -->
                                <input type="text" class="form-control col-6" name="eventDescription" value="<?php echo e($event->users()->count()); ?>" readonly><hr>


                            </div>
                            <?php if(isset(Auth::user()->id)): ?> <!--Only when user is logged in -->
                                <form method="post" action="/subscribe/<?php echo e($event->id); ?>/<?php echo e(Auth::user()->id); ?>" >
                                    <?php echo e(csrf_field()); ?>


                                   <!--!!! https://www.tutorialspoint.com/laravel/laravel_sending_email.htm -->

                                    <input type="submit" name="Submit" value="Sign Up">
                                </form>
                                <a href="/" class="btn btn-success">Back</a>
                                <?php if(isset($result) and !empty($result)): ?>
                                    <hr>
                                    <h4>Files to Download </h4>

                                     <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <a href="/file/download/<?php echo e($event->id); ?>/<?php echo e($res); ?>"><?php echo e($res); ?></a>
                                         <br>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <!--<a href=>Thing</a> -->
                                <!--Storage::allFiles(app/public/images/); -->

                                <!--Storage::allFiles(storage/app/public/uploads);
                                <a href=" " class="btn btn-primary ">Download</a>-->
                            
                                <hr />

                                <h4>Comments</h4>
                            <!--
                                <?php echo $__env->make('commentsReply', ['comments' => $event->comments, 'event_id' => $event->id], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            -->
                                <?php echo $__env->make('partials._comment_replies', ['comments' => $event->comments, 'event_id' => $event->id], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <form method="post" action="/comments/store">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <textarea class="form-control" name="message"></textarea>
                                        <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>" />
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-success" value="Add Comment" />
                                    </div>
                                </form>

                            <?php else: ?>
                            <label>Please, log in to subscribe for this event..</label>
                        <?php endif; ?>
                            <br>
                        <div class="offset-5">
                        <?php if(!isset(Auth::user()->id)): ?> <!--Only while user is NOT logged in -->
                            <a href="/home" class="btn btn-success">Log In</a>
                        <?php endif; ?>
                            <a href="/" class="btn btn-success">Back</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6" >
                <div id="stamp">
                    Today is:&nbsp;&nbsp;&nbsp;&nbsp;<b><span id="ct"></span></b>
                </div>
                <div id="map">
                    <!-- link describes why $selected has not been set, so map is not shown:  https://stackoverflow.com/questions/53500201/undefined-variable-laravel-->
                    <?php if(isset($selected)): ?>

                        <!-- Displaying the map -->
                        <?php

                            if ($selected == "Casa Loma"){
                                echo "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2885.65543464594!2d-79.41267698477122!3d43.67613545896579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b349c7e14727f%3A0x8bd06e05bd9af30d!2sGeorge+Brown+College+Casa+Loma+Campus!5e0!3m2!1sen!2sca!4v1550117318645' width='500' height='350' frameborder='0' style='border:0' allowfullscreen></iframe>";
                            }
                            else if($selected == "St.James"){
                                echo "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.8500436395975!2d-79.372422384772!3d43.65128816057281!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb308d8c451f%3A0x2a2d39cb9b79ac42!2sGeorge+Brown+College+St.+James+Campus!5e0!3m2!1sen!2sca!4v1550117358751' width='500' height='350' frameborder='0' style='border:0' allowfullscreen></iframe>";
                            }
                            else{
                                echo "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.1109232844424!2d-79.36687739508416!3d43.645860485513914!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb24382107b9%3A0xd5913915d08fdc8a!2sGeorge+Brown+College+Waterfront+Campus!5e0!3m2!1sen!2sca!4v1550117470344' width='500' height='350' frameborder='0' style='border:0' allowfullscreen></iframe>";
                            }
                        ?>

                    <?php endif; ?>
                </div>




            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>