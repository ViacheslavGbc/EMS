<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-2">
            <div class="card">

                <div class="card-header h2">Modify Event:&nbsp;&nbsp;&nbsp;<?php echo e($event->eventName); ?></div>

                <div class="card-body">
                    <form action="https://w9team1.gblearn.com/GBCEvent/public/update/<?php echo e($event->id); ?>" method="post">
                        <label class="col-form-label">Event Manager</label>
                        <input type="text" class="form-control" name="eventOwner" value="<?php echo e($event->eventOwner); ?>" required>
                        <label class="col-form-label">Full Event Title</label>
                        <input type="text" class="form-control" name="eventName" value="<?php echo e($event->eventName); ?>" required>
                        <label class="col-form-label"> Dates & Times</label>
                        <input type="date" class="form-control" name="eventDate1" value="<?php echo e($event->eventDate1); ?>" required>
                        <br>
                        <input type="date" class="form-control" name="eventDate2" value="<?php echo e($event->eventDate2); ?>" required>
                        <label class="col-form-label"> Location & Room </label>
                        <input type="text" class="form-control" name="eventLocation" value="<?php echo e($event->eventLocation); ?>" required>
                        <label class="col-form-label"> Max. Participants </label>
                        <input type="text" class="form-control" name="maxNumParticipants" value="<?php echo e($event->maxNumParticipants); ?>" required>
                        <label class="col-form-label"> Detailed Description</label>
                        <textarea type="text"  class="form-control" name="eventDescription" required><?php echo e($event->eventDescription); ?>"</textarea>
                        <hr>
                        <?php echo e(csrf_field()); ?>

                        <div class="offset-4">
                            <input type="submit"  class="btn btn-success" name="Submit" value="Save Changes">&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="https://w9team1.gblearn.com/GBCEvent/public/home" class="btn btn-success">Cancel</a>

                        </div>

                    </form>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>